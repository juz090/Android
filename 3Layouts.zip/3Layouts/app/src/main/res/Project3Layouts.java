public class Project3Layouts extends Activity {

	Button btn;
	EditText edtText;
	CheckBox chkBox;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//setContentView(R.layout.linear);  //Test Different layouts
		//setContentView(R.layout.frame);
		//setContentView(R.layout.relative);
		//setContentView(R.layout.table);
		setContentView(R.layout.scroll);
		//and more


	}